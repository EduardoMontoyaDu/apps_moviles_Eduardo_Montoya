package com.example.login

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Intent
import kotlin.jvm.java
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        setContentView(R.layout.activity_main)

        val etUser = findViewById<EditText>(R.id.usuario)
        val etPass = findViewById<EditText>(R.id.contra)
        val btnlog = findViewById<Button>(R.id.btning)

        btnlog.setOnClickListener {
            val user = etUser.text.toString().trim()
            val pass = etPass.text.toString()

            //Validacion
            if (user.isEmpty()) {
                etUser.error = "Ingresa tu usuario"
                etUser.requestFocus()
                return@setOnClickListener
            }
            if (pass.isEmpty()){
                etPass.error = "Ingresa tu contraseña"
                etPass.requestFocus()
                return@setOnClickListener
            }
            //Autentificacion demo
            if (autentificate(user, pass)){
                val intent = Intent(this, carrusel::class.java).apply{
                    putExtra("EXTRA_USER", user)
                }
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this,"Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

private fun MainActivity.autentificate(user: String, pass: String): Boolean {
    return user == "admin" && pass == "1234"
}
